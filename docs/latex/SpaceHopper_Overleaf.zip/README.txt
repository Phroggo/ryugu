SpaceHopper — IEEE two-column paper (Overleaf package)

To edit in Overleaf (free, no install):
  1. Go to overleaf.com -> New Project -> Upload Project
  2. Upload this entire .zip
  3. Set the main document to  spacehopper_ieee.tex  (Menu -> Main document)
  4. Compiler: pdfLaTeX (Menu -> Settings). Click Recompile.

Files:
  spacehopper_ieee.tex  - the paper (edit this)
  IEEEtran.cls          - IEEE conference two-column class
  *.png / *.pdf         - the 14 figures (4 diagrams are PDFs, rest are photos)

The document class is \documentclass[conference]{IEEEtran} = IEEE 2-column.
